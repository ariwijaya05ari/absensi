// ============================================================================
//  KONFIGURASI FRONTEND — satu-satunya nilai yang perlu Anda isi.
//  Tempel URL Web App Google Apps Script (berakhiran /exec) di bawah ini.
//  URL ini BUKAN rahasia; keamanan dijaga oleh token sesi + cek peran di server.
// ============================================================================
window.APP_CONFIG = {
  GAS_URL: 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT/exec'
};
